#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL_image.h"
#include "SDL/SDL.h"
#include "SDL/SDL_mixer.h"
#include "SDL/SDL_ttf.h"
#include "setting.h"
#include "fun.h"
int globalConter;
int currentBG;
SDL_Surface *bglmgs[6];
void initMenu(menu * m){
    m->background=IMG_Load("background.png");
    m->pos.x = 0; m->pos.y=0;
    m->pos.h = m->background->h;
    m->pos.w = m->background->w;
     globalConter=0;
      currentBG=0;
           //animation
bglmgs[0]=IMG_Load("1.png");
          bglmgs[1]=IMG_Load("2.png");
          bglmgs[2]=IMG_Load("3.png");
          bglmgs[3]=IMG_Load("4.png");
          bglmgs[4]=IMG_Load("5.png");
          bglmgs[5]=IMG_Load("6.png");
    if(m->background==NULL)
	{
        printf("unable to load button :%s\n",SDL_GetError());
    	return;
    	}
    	/*m->gamename=IMG_Load("gamename.png");
	m->pos.x = 350; m->pos.y=200;
    	m->pos.h = m->gamename->h;
    	m->pos.w = m->gamename->w;
    if(m->gamename==NULL)
	{
        printf("unable to load button :%s\n",SDL_GetError());
    	return;
    	}*/		
    int i ;
    for(i = 0; i<=7; i++){
        switch(i){
            case 0: //this is play butt
                m->b[0].img=IMG_Load("newgame1.png");
                m->b[0].hover=IMG_Load("newgame2.png");
                m->b[0].fin=IMG_Load("newgame3.png");
                m->b[0].pos.x=420;
                m->b[0].pos.y=390;
                m->b[0].pos.h=m->b[0].img->h;
                m->b[0].pos.w=m->b[0].img->w;
                m->b[0].itIsHovered = 0;
            break;
            case 1 : // this is continue butt
            m->b[1].img=IMG_Load("continue1.png");
            m->b[1].hover=IMG_Load("continue2.png");
            m->b[1].fin=IMG_Load("continue3.png");
                m->b[1].pos.x=420;
                m->b[1].pos.y=470;
                m->b[1].pos.h=m->b[1].img->h;
                m->b[1].pos.w=m->b[1].img->w;
                 m->b[1].itIsHovered = 0;
            break;
            case 9 : // this is save butt
            m->b[9].img=IMG_Load("save1.png");
            m->b[9].hover=IMG_Load("continue2.png");
            m->b[9].fin=IMG_Load("continue3.png");
                m->b[9].pos.x=400;
                m->b[9].pos.y=360;
                m->b[9].pos.h=m->b[1].img->h;
                m->b[9].pos.w=m->b[1].img->w;
                 m->b[9].itIsHovered = 0;
            break;
            case 2 ://this is settings butt
                m->b[2].img=IMG_Load("settings1.png");
                m->b[2].hover=IMG_Load("settings2.png");
                m->b[2].fin=IMG_Load("settings3.png");
                m->b[2].pos.x=420;
                m->b[2].pos.y=540;
                m->b[2].pos.h=m->b[2].img->h;
                m->b[2].pos.w=m->b[2].img->w;
                 m->b[2].itIsHovered = 0;
            break;
            case 8 ://this is multiplayer butt
                m->b[8].img=IMG_Load("settings1.png");
                m->b[8].hover=IMG_Load("settings2.png");
                m->b[8].fin=IMG_Load("settings3.png");
                m->b[8].pos.x=420;
                m->b[8].pos.y=540;
                m->b[8].pos.h=m->b[2].img->h;
                m->b[8].pos.w=m->b[2].img->w;
                 m->b[8].itIsHovered = 0;
            break;
            case 3 : // out
            m->b[3].img=IMG_Load("quit1.png");
            m->b[3].hover=IMG_Load("quit2.png");
            m->b[3].fin=IMG_Load("quit3.png");
                m->b[3].pos.x=420;
                m->b[3].pos.y=620;
                m->b[3].pos.h=m->b[3].img->h;
                m->b[3].pos.w=m->b[3].img->w;
                 m->b[3].itIsHovered = 0;
            break;
            case 7 : // game name
            m->b[7].img=IMG_Load("gamename.png");
                m->b[7].pos.x=200;
                m->b[7].pos.y=-20;
                m->b[7].pos.h=m->b[7].img->h;
                m->b[7].pos.w=m->b[7].img->w;
                m->b[7].itIsHovered = 0;
            break;
            case 6: //this is character
                m->b[6].img=IMG_Load("character.png");
                m->b[6].pos.x=520;
                m->b[6].pos.y=150;
                m->b[6].pos.h=m->b[6].img->h;
                m->b[6].pos.w=m->b[6].img->w;
                m->b[6].itIsHovered = 0;
            break;
            case 4: //this is sound butt
                m->b[4].img=IMG_Load("soundon.png");
                m->b[4].fin=IMG_Load("soundoff.png");
                m->b[4].pos.x=5;
                m->b[4].pos.y=15;
                m->b[4].pos.h=m->b[4].img->h;
                m->b[4].pos.w=m->b[4].img->w;
                m->b[4].itIsHovered = 0;
            break;
            case 5: //this is music butt
                m->b[5].img=IMG_Load("musicon.png");
                m->b[5].fin=IMG_Load("musicoff.png");
                m->b[5].pos.x=80;
                m->b[5].pos.y=15;
                m->b[5].pos.h=m->b[5].img->h;
                m->b[5].pos.w=m->b[5].img->w;
                m->b[5].itIsHovered = 0;
            break;
        }
    }

}

void showMenu(menu m, SDL_Surface * screen){
    //SDL_BlitSurface(m.background,NULL,screen,&(m.pos));

 globalConter++;
         if(globalConter % 50 == 0)
            {
              currentBG++;
              currentBG = currentBG % 6;
            SDL_BlitSurface(bglmgs[currentBG], NULL, screen, NULL);

            }

    int i=0;
    for(i = 0; i<=7; i++){
        if(m.b[i].itIsHovered == 0){
            SDL_BlitSurface(m.b[i].img, NULL, screen, &(m.b[i].pos));
        }else if(m.b[i].itIsHovered == 1){
            SDL_BlitSurface(m.b[i].hover, NULL, screen, &(m.b[i].pos));
        }
else if(m.b[i].itIsHovered == 2)
                   { if(i==0)
{      
     SDL_BlitSurface(m.b[0].fin, NULL, screen, &(m.b[0].pos));
 newnew();
}
else
{     SDL_BlitSurface(m.b[i].fin, NULL, screen, &(m.b[i].pos));}
                       }


    }

}
void initSett(settings * set){
    int per;
    FILE * f = fopen("settings.txt","r");
    if(f == NULL){
        f = fopen("settings.txt", "w");
        fprintf(f, "%d\n", 64);
    }else{
        fscanf(f, "%d\n", &per);
    }
     fclose(f);

    f = fopen("settings.txt","r");
    fscanf(f, "%d\n", &per);
    fclose(f);
    printf("Volume percentage: %d\n", per);
	set->settbackground = IMG_Load("background_settings2.png");
    set->b[0].img = IMG_Load("Asset15.png");
	set->b[1].img  = IMG_Load("plus.png");
	set->b[2].img  = IMG_Load("moins.png");
	set->b[3].img  = IMG_Load("Asset10.png");
	set->b[4].img  = IMG_Load("Asset6.png");
        set->b[5].img  = IMG_Load("Asset8.png");


    //this is for text showing and font stuff
	char ch[128];
    SDL_Surface *value = NULL;
    SDL_Rect valuePos;
    TTF_Font* police = NULL;
    SDL_Color color = {220, 20, 60};

    if (TTF_Init() < 0) {
      printf("Error openning ttf\n");
    }else{
      police = TTF_OpenFont("font.ttf", 30);
      if (police == NULL) {
        printf("Error in opening font file\n");
      }else{
        sprintf(ch, "%d", per);
        value=TTF_RenderText_Solid(police, ch, color);
        TTF_CloseFont(police);
        TTF_Quit();
      }
      valuePos.x = 96;
      valuePos.y = 20;
    }

    set->volumePer = value; // this is volume percent img

    //this is for back button
    set->b[0].pos.x =420; set->b[0].pos.y=570;
	set->b[0].pos.h = set->b[0].img->h;  set->b[0].pos.w = set->b[0].img->w;
   

	//this is for background paper
	set->setbpos.x = 0; set->setbpos.y=0;
	set->setbpos.h = set->settbackground->h; set->setbpos.w = set->settbackground->w;
    //this is for volume up button
	set->b[1].pos.x = 630; set->b[1].pos.y=170;
    set->b[1].pos.h = set->b[1].img->h; set->b[1].pos.w = set->b[1].img->w;

    //this is for volume down button
    set->b[2].pos.x = 770; set->b[2].pos.y= 175;
    set->b[2].pos.h = set->b[2].img->h; set->b[2].pos.w = set->b[2].img->w;
    //this for mode button

    set->b[3].pos.x = 650; set->b[3].pos.y=278;

    set->b[4].pos.x = 750; set->b[4].pos.y=300;

    set->b[3].pos.h = set->b[3].img->h; set->b[3].pos.w = set->b[3].img->w;

	set->b[4].pos.h = set->b[4].img->h; set->b[4].pos.w = set->b[4].img->w;
 //this is for mode play button
	set->b[5].pos.x = 635; set->b[5].pos.y=465;
    set->b[5].pos.h = set->b[5].img->h; set->b[5].pos.w = set->b[5].img->w;

    //init pos of volume percentage
    set->volPos.x = 720; set->volPos.y = 190;


}
int settingsClicks(SDL_Event event, settings *s,SDL_Surface *screen){
    int ff = 0;
    int x = -1;
    for(ff = 0; ff <= 5; ff++){
        if(((event.motion.x <= s->b[ff].pos.x + s->b[ff].img->w) && 
        (event.motion.x >= s->b[ff].pos.x)) && 
        ((event.motion.y >= s->b[ff].pos.y) && 
        (event.motion.y <= s->b[ff].pos.y + s->b[ff].img->h))) {
            //Mix_PlayChannel(-1, s.b[ff].sClick, 0);
            x = ff;
            printf("%d" ,x);
        }
    }
    switch(x){
        case 0: //go back butt was pressed
            return 0;
        break;
        case 1: // if vol up was pressed
            manageVolume(s,1);
  SDL_BlitSurface(s->volumePer,NULL,screen,&(s->volPos));
        break;
        case 2: // if vol down was pressed
        printf("rrr");
            manageVolume(s,0);
  SDL_BlitSurface(s->volumePer,NULL,screen,&(s->volPos));
        break;
        case 3: // normale screen
            manageMode(0);
        break;
        case 4: // full screen
            manageMode(1);
        break;
    }
    return -1;
}
void showSett(settings set, SDL_Surface * screen){

    SDL_BlitSurface(set.settbackground,NULL,screen,&(set.setbpos));
    SDL_BlitSurface(set.b[0].img,NULL,screen,&(set.b[0].pos));
    SDL_BlitSurface(set.volumePer,NULL,screen,&(set.volPos));
    SDL_BlitSurface(set.b[1].img,NULL,screen,&(set.b[1].pos));
    SDL_BlitSurface(set.b[2].img,NULL,screen,&(set.b[2].pos));
    SDL_BlitSurface(set.b[3].img,NULL,screen,&(set.b[3].pos));
    SDL_BlitSurface(set.b[4].img,NULL,screen,&(set.b[4].pos));
    SDL_BlitSurface(set.b[5].img,NULL,screen,&(set.b[5].pos));
    SDL_BlitSurface(set.b[8].img,NULL,screen,&(set.b[8].pos));
    SDL_BlitSurface(set.b[9].img,NULL,screen,&(set.b[9].pos));

}
//SDL_Flip(screen);

/*void initCredits(credits * c){
 c->img=IMG_Load("cursor.png");
 c->pos.x=0;c->pos.y=0;
 c->pos.h=c->img->h;
 c->pos.w=c->img->w;

}/*
//void showCredits(credits c, SDL_Surface * screen){
   // SDL_BlitSurface(c.img, NULL, screen, &c.pos);
 SDL_Flip(screen);
}*/
