#ifndef BACKGROUND_H_INCLUDED
#define BACKGROUND_H_INCLUDED

#include <stdio.h>
#include "SDL/SDL_image.h"
#include "SDL/SDL.h"
#include "SDL/SDL_mixer.h"
#include <stdlib.h>


typedef struct{
    SDL_Surface * img;
    SDL_Surface *hover;
    SDL_Surface *fin;
    int itIsHovered;
    SDL_Rect pos;
}button;
typedef struct {
    SDL_Surface* background;
    SDL_Rect pos;
    button b[10];
}menu;
typedef struct {
    SDL_Surface *settbackground;
    SDL_Rect setbpos;
    SDL_Surface * volumePer;
    SDL_Rect volPos;
    button b[6];
}settings;
typedef struct 
{   SDL_Surface * img;
    SDL_Rect pos3;
}stage;

void initMenu(menu * m);
void showMenu(menu m, SDL_Surface * screen);
void newnew();
void initSett(settings * set);
void showSett(settings set, SDL_Surface * screen);
int settingsClicks(SDL_Event event, settings *s,SDL_Surface *screen);
#endif


