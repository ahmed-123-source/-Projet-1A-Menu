#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL_image.h"
#include "SDL/SDL.h"
#include "SDL/SDL_mixer.h"
#include "fun.h"
void pause()
{
int continuer = 1;
SDL_Event event;
while (continuer)
{
SDL_WaitEvent(&event);
switch(event.type)
{
case SDL_QUIT:
continuer = 0;
}
}
}
void newnew()
{
SDL_Surface *ecran = NULL;
SDL_Init(SDL_INIT_VIDEO);
ecran =SDL_SetVideoMode(1245,699,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
SDL_WM_SetCaption("LOGIC MASE", NULL);
if( Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1){
		printf("ERROR: Unable to initialize SDL SOUNDS" );
	}

	SDL_Surface *curs =IMG_Load("cursor.png");
	SDL_ShowCursor(0);
	SDL_Rect ms;
	ms.w=curs->w;
	ms.h=curs->h;
    Mix_Music *music;
	music=Mix_LoadMUS("music.mp3");
	Mix_PlayMusic(music,-1);
// Coloration de la surface ecran en bleu-vert
SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 17, 206, 112));
SDL_Flip(ecran); /* Mise à jour de l'écran avec sa nouvelle couleur */
pause();
SDL_Quit();

}
