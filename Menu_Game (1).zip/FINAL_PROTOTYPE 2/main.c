#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_mixer.h"
#include "SDL/SDL_ttf.h"
#include "fun.h"
#include <stdio.h>
#include <stdlib.h>

int main (void){
int globalconter=0;
int currentBG=0;
  

	// screen initialization
	SDL_Surface * screen = NULL;
	if(SDL_Init(SDL_INIT_VIDEO)!=0){
		printf( "ERROR: Unable to initialize SDL");
		return 1;
	}
	//Initialize SDL SOUND
	if( Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1){
		printf("ERROR: Unable to initialize SDL SOUNDS" );
	}
	screen = SDL_SetVideoMode(1245,950,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	SDL_WM_SetCaption("LOGIC MAZE", NULL);
	SDL_Surface *curs =IMG_Load("cursor.png");
	SDL_ShowCursor(0);
	SDL_Rect ms;
	ms.w=curs->w;
	ms.h=curs->h;
    Mix_Music *music;
	music=Mix_LoadMUS("music.mp3");
	Mix_PlayMusic(music,-1);

	//credits init
	//credits c;
	//initCredits(&c);
	//==============

	SDL_Event event;
SDL_Event event2;
    menu m;
int signal;
settings set;
	int game_done = 0;
int	game_done2=0;
int settingsSignal;
	initMenu(&m);
	while(game_done == 0){
			showMenu(m, screen);
			SDL_BlitSurface(curs,NULL,screen,&ms);
			SDL_Flip(screen);
		while(SDL_PollEvent(&event) == 1){// o
			  switch(event.type){

				case SDL_MOUSEMOTION: //  mouse
                     
                		ms.x = event.motion.x;
                		ms.y = event.motion.y;


						if(((event.motion.x <= m.b[0].pos.x + m.b[0].img->w) &&
						(event.motion.x >= m.b[0].pos.x)) &&
						((event.motion.y >= m.b[0].pos.y) &&
						(event.motion.y <= m.b[0].pos.y + m.b[0].img->h))) {
							m.b[0].itIsHovered = 1;
							int j;
										for(j=0; j<=5; j++){
											if(j !=0 ){
												m.b[j].itIsHovered = 0;
											}
										}
						}else{
							if(((event.motion.x <= m.b[1].pos.x + m.b[1].img->w) &&
							(event.motion.x >= m.b[1].pos.x)) &&
							((event.motion.y >= m.b[1].pos.y) &&
							(event.motion.y <= m.b[1].pos.y + m.b[1].img->h))) {
							m.b[1].itIsHovered = 1;
							int j;
										for(j=0; j<=5; j++){
											if(j != 1){
												m.b[j].itIsHovered = 0;
											}
										}
							}
							else{
								if(((event.motion.x <= m.b[2].pos.x + m.b[2].img->w) &&
								(event.motion.x >= m.b[2].pos.x)) &&
								((event.motion.y >= m.b[2].pos.y) &&
								(event.motion.y <= m.b[2].pos.y + m.b[2].img->h))) {
							m.b[2].itIsHovered = 1;
										int j;
										for(j=0; j<=5; j++){
											if(j != 2){
												m.b[j].itIsHovered = 0;
											}
										}
								}
							/*else{
								if(((event.motion.x <= m.b[4].pos.x + m.b[4].img->w) &&
								(event.motion.x >= m.b[4].pos.x)) &&
								((event.motion.y >= m.b[4].pos.y) &&
								(event.motion.y <= m.b[4].pos.y + m.b[4].img->h))) {
							m.b[4].itIsHovered = 1;
										int j;
										for(j=0; j<=5; j++){
											if(j != 4){
												m.b[j].itIsHovered = 0;
											}
										}
								}*/
								else{
									if(((event.motion.x <= m.b[3].pos.x + m.b[3].img->w) &&
									(event.motion.x >= m.b[3].pos.x)) &&
									((event.motion.y >= m.b[3].pos.y) &&
									(event.motion.y <= m.b[3].pos.y + m.b[3].img->h))) {
							m.b[3].itIsHovered = 1;
										int j;
										for(j=0; j<=5; j++){
											if(j != 3){
												m.b[j].itIsHovered = 0;
											}
										}
									}else{
										int j;
										for(j=0; j<=3; j++){
											m.b[j].itIsHovered = 0;
										}
									}
								}

							}
						}
           		     break;


				case SDL_QUIT:
				game_done=1; //quit game
			    break;


			    case SDL_MOUSEBUTTONDOWN:
					if(((event.motion.x <= m.b[0].pos.x + m.b[0].img->w) &&
					(event.motion.x >= m.b[0].pos.x)) &&
					((event.motion.y >= m.b[0].pos.y) &&
					(event.motion.y <= m.b[0].pos.y + m.b[0].img->h))) {
							m.b[0].itIsHovered =2;
                                                  
						printf("new game button\n");

                 	}else{
						 if(((event.motion.x <= m.b[1].pos.x + m.b[1].img->w) &&
						(event.motion.x >= m.b[1].pos.x)) &&
						((event.motion.y >= m.b[1].pos.y) &&
						(event.motion.y <= m.b[1].pos.y + m.b[1].img->h))) {
							m.b[1].itIsHovered = 2;
							printf("continue button\n");



						}else{
							 if(((event.motion.x <= m.b[2].pos.x + m.b[2].img->w) &&
							(event.motion.x >= m.b[2].pos.x)) &&
							((event.motion.y >= m.b[2].pos.y) &&
							(event.motion.y <= m.b[2].pos.y + m.b[2].img->h))) {
							
                                                          m.b[2].itIsHovered = 2;
initSett(& set);
while(game_done2 == 0){
			showSett(set, screen);
                              
			SDL_BlitSurface(curs,NULL,screen,&ms);
			SDL_Flip(screen);
while(SDL_PollEvent(&event2) == 1){
     switch(event2.type){ case SDL_MOUSEMOTION: //  mouse
                     
                		ms.x = event2.motion.x;
                		ms.y = event2.motion.y;
					break;
				case SDL_MOUSEBUTTONDOWN:
                		


						settingsSignal = settingsClicks(event2, &set, screen);
                                                          printf(" %d \n",settingsSignal);
						if(settingsSignal == 0){
							
                                                        game_done2 = 1;
						}
					break;
                                                          
					
                      			SDL_Flip(screen);
				break;	
                               		}
while(SDL_PollEvent(&event2) == 1);
}
}
                                                          printf("settings button\n");
							
							}else{
								 if(((event.motion.x <= m.b[3].pos.x + m.b[3].img->w) &&
								(event.motion.x >= m.b[3].pos.x)) &&
								((event.motion.y >= m.b[3].pos.y) &&
								(event.motion.y <= m.b[3].pos.y + m.b[3].img->h))) {
							m.b[3].itIsHovered = 2;								
									printf("quit button\n");
									game_done=1;
								}
							}
						}
					}
				break;

			  }
			  while(SDL_PollEvent(&event) == 1);
		}
	}

	SDL_FreeSurface(curs);
	Mix_FreeMusic(music);
	Mix_CloseAudio();
	SDL_FreeSurface(screen);

	return 0 ;

}


